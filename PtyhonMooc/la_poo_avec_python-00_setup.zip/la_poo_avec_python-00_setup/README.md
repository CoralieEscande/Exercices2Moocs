# Apprenez la POO avec Python

Projet servant de fil rouge au cours Apprenez la POO avec Python, disponible sur OpenClassrooms. 

Nous simulons ici un monde virtuel peuplé de 100 000 personnes. Nous cherchons à connaître :
- à partir de quelle densité de population les personnes sont moins agréables que la moyenne,
- à partir de quel âge les personnes gagnent plus d'argent que la moyenne.

Lorsque le programme se lance, une première fenêtre affiche un graphique concernant la densité de population puis une seconde concernant le revenu.